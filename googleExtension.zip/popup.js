document.addEventListener('DOMContentLoaded', function() {
    var inputPanel = document.getElementById('inputPanel');
    var inputField = document.getElementById('inputField');
  
    // Фокус на поле ввода при открытии панели
    inputField.focus();
  });
  