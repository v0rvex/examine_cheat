// Функция для загрузки данных JSON с указанного URL и сохранения их в локальное хранилище
answers = ''

function createResultsPanel() {
    var resultsPanel = document.createElement('div');
    resultsPanel.id = 'resultsPanel';
    resultsPanel.style.position = 'fixed';
    resultsPanel.style.bottom = '100px';
    resultsPanel.style.right = '10px';
    resultsPanel.style.width = '150px';
    resultsPanel.style.maxHeight = '130px';
    resultsPanel.style.overflowY = 'auto';
    resultsPanel.style.padding = '5px';
    resultsPanel.style.backgroundColor = 'white';
    resultsPanel.style.border = '1px solid #ccc';
    resultsPanel.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.1)';
    resultsPanel.style.display = 'none'; // Скрываем панель по умолчанию
    resultsPanel.style.opacity = '0'
    resultsPanel.style.transition = 'opacity 0.3s';
    resultsPanel.style.fontSize = '0.9rem'

    resultsPanel.addEventListener('mouseover', function() {
        resultsPanel.style.opacity = '0.5';
      });
    resultsPanel.addEventListener('mouseout', function() {
        resultsPanel.style.opacity = '0';
      });

    document.body.appendChild(resultsPanel);
  }

function loadAndSaveData() {
    // Загружаем данные с URL
    fetch('https://raw.githubusercontent.com/v0rvex/v0rvex.github.io/main/index.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        answers = data
      })
      .catch(error => {
        console.error('Error loading data:', error);
      });
  }
  
  // Вызываем функцию для загрузки и сохранения данных при запуске расширения
  loadAndSaveData();  

// Функция для добавления панели и кнопок
function addPanelAndButtons() {

    createResultsPanel(); // Создаем панель для результатов

    var inputPanel = document.createElement('div');
    inputPanel.id = 'inputPanel';
    inputPanel.style.position = 'fixed';
    inputPanel.style.bottom = '50px';
    inputPanel.style.right = '10px';
    inputPanel.style.width = '150px';  // Уменьшенный размер панели
    inputPanel.style.padding = '5px';  // Уменьшенное внутреннее поле
    inputPanel.style.backgroundColor = 'white';
    inputPanel.style.border = '1px solid #ccc';
    inputPanel.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.1)';
    inputPanel.style.opacity = 0.2;
    
    var inputField = document.createElement('input');
    inputField.type = 'text';
    inputField.id = 'inputField';
    inputField.placeholder = 'Enter text...';
    inputField.style.width = '100%';
    inputField.style.padding = '5px';
    inputField.style.border = '1px solid #ccc';
    inputField.style.borderRadius = '3px';

    // Создаем кнопку для удаления расширения
    var deleteButton = document.createElement('button');
    deleteButton.textContent = 'Remove Extension';
    deleteButton.id = 'removeExtensionButton';
    deleteButton.style.position = 'fixed';
    deleteButton.style.bottom = '10px';
    deleteButton.style.right = '90px';  // Размещаем кнопку рядом с кнопкой открытия панели
    deleteButton.style.zIndex = 1000;
    deleteButton.style.padding = '5px 10px';
    deleteButton.style.backgroundColor = 'rgba(220, 53, 69, 0.5)';
    deleteButton.style.color = 'white';
    deleteButton.style.border = 'none';
    deleteButton.style.borderRadius = '5px';
    deleteButton.style.cursor = 'pointer';
    deleteButton.style.fontSize = '10px';  // Уменьшенный размер шрифта
    deleteButton.style.opacity = '0';    // Сделаем кнопку менее заметной
    deleteButton.style.transition = 'opacity 0.3s';
    //Обработчик события для ввода текста
    inputField.addEventListener('input', function() {
        // Получаем текущее значение из inputField
        var keyword = inputField.value.trim();
        // Вызываем функцию поиска
        searchByKeyWord(keyword);
      });
    // Обработчики событий для изменения прозрачности при наведении мыши
    deleteButton.addEventListener('mouseover', function() {
      deleteButton.style.opacity = '0.5';
    });
    deleteButton.addEventListener('mouseout', function() {
      deleteButton.style.opacity = '0';
    });
  
    deleteButton.addEventListener('click', function() {
      // Удаляем все, связанное с расширением
      chrome.runtime.sendMessage({ action: 'uninstall' });
  
      // Удаляем панель и кнопки
      document.body.removeChild(inputPanel);
      document.body.removeChild(deleteButton);
      document.body.removeChild(toggleButton); // Удаляем кнопку "Toggle Panel"

      var resultsPanel = document.getElementById('resultsPanel');
        if (resultsPanel) {
        document.body.removeChild(resultsPanel); // Удаляем панель результатов
    }
  
      // Отключаем обработчики событий
      deleteButton.removeEventListener('mouseover');
      deleteButton.removeEventListener('mouseout');
      deleteButton.removeEventListener('click');
      
      // Удаляем все content script'ы
      var allContentScripts = document.querySelectorAll('script[src^="chrome-extension://"]');
      allContentScripts.forEach(function(script) {
        script.parentNode.removeChild(script);
      });
  
      // Удаляем background script
      chrome.runtime.sendMessage({ action: 'removeBackgroundScript' });
  
      // Удаляем запись из storage
      chrome.storage.local.remove('panelAdded');
    });
    
    inputPanel.appendChild(inputField);
    document.body.appendChild(inputPanel);
    document.body.appendChild(deleteButton);
    
    inputField.focus();
  }
  
  // Создаем кнопку для открытия/закрытия панели
  var toggleButton = document.createElement('button');
  toggleButton.textContent = 'Toggle Panel';
  toggleButton.id = 'togglePanelButton';
  toggleButton.style.position = 'fixed';
  toggleButton.style.bottom = '10px';
  toggleButton.style.right = '10px';
  toggleButton.style.zIndex = 1000;
  toggleButton.style.padding = '5px 10px';
  toggleButton.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
  toggleButton.style.color = 'white';
  toggleButton.style.border = 'none';
  toggleButton.style.borderRadius = '5px';
  toggleButton.style.cursor = 'pointer';
  toggleButton.style.fontSize = '10px';  // Уменьшенный размер шрифта
  toggleButton.style.opacity = '0';    // Сделаем кнопку менее заметной
  toggleButton.style.transition = 'opacity 0.3s';
  
  // Обработчики событий для изменения прозрачности при наведении мыши
  toggleButton.addEventListener('mouseover', function() {
    toggleButton.style.opacity = '0.5';
  });
  toggleButton.addEventListener('mouseout', function() {
    toggleButton.style.opacity = '0';
  });
  
  // Добавляем кнопку на страницу
  document.body.appendChild(toggleButton);
  
  // Обработчик клика по кнопке "Toggle Panel"
  toggleButton.addEventListener('click', function() {
    var existingPanel = document.getElementById('inputPanel');
    var resultsPanel = document.getElementById('resultsPanel');
    if (!existingPanel) {
      addPanelAndButtons();
      
      // Сохраняем информацию о добавленной панели в storage
      chrome.storage.local.set({ 'panelAdded': true });
    } else {
      // Удаляем панель и кнопки, если панель уже открыта
      document.body.removeChild(existingPanel);
      document.body.removeChild(resultsPanel);
      var deleteButton = document.getElementById('removeExtensionButton');
      if (deleteButton) {
        document.body.removeChild(deleteButton);
      }
    }
  });
  
  // Проверяем, была ли панель добавлена ранее
  chrome.storage.local.get('panelAdded', function(result) {
    if (result.panelAdded) {
      addPanelAndButtons();
    }
  });
  
//Функция поиска по слову
function searchByKeyWord(keyword) {
    // Результаты поиска будем сохранять здесь
    let searchResults = [];
  
    // Перебираем нужные разделы и ищем keyword
    ['RuLang', 'History', 'Physics', 'KzLang'].forEach(function(section) {
        // Перебираем ключи и значения в текущем разделе
        for (key in answers[section][0]) {
          if (answers[section][0].hasOwnProperty(key)) {
            if (key.toLowerCase().includes(keyword.toLowerCase()) ||
                answers[section][0][key].toString().toLowerCase().includes(keyword.toLowerCase())) {
              searchResults.push(answers[section][0][key]);
            }
          }
        }
      }
    );
    updateResultsPanel(searchResults);
  }

  function updateResultsPanel(results) {
    var resultsPanel = document.getElementById('resultsPanel');
    if (resultsPanel) {
      if (results.length > 0) {
        resultsPanel.innerHTML = results.map(result => 
          `<div><strong>${result}</strong></div>`
        );
        resultsPanel.style.display = 'block';
      } else {
        resultsPanel.innerHTML = '';
        resultsPanel.style.display = 'none';
      }
    }
  }
