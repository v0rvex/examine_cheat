chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'uninstall') {
    chrome.storage.local.remove('panelAdded');
    chrome.management.uninstallSelf();
  }
});
